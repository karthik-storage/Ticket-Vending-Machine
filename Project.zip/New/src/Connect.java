/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author JEEVAN SAI
 */
import java.sql.*;
import javax.swing.*;
public class Connect {
    Connection conn=null;
    ResultSet rs=null;
    PreparedStatement pst=null;
    public static Connection ConnectDB() {
        try{
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection conn=DriverManager.getConnection("jdbc:odbc:Driver={Microsoft Access Driver(*.mdb)}; DBQ=db2.mdb");
        return conn;            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }
}
