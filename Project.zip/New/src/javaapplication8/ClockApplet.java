/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication8;


import java.awt.*;
import java.applet.*;

import java.applet.*;
import java.awt.*;
import java.util.*;

        public class ClockApplet extends Applet implements Runnable{
      
  public void init()
  {
  setBackground(Color.GREEN);
  }
  Thread t,t1;
  //setBackground(Color.GREEN);
  public void start(){
      t = new Thread(this);
      t.start();
   }
   public void run(){
      t1 = Thread.currentThread();
      while(t1 == t){
         repaint();
         try{
            t1.sleep(1000);    
         }
         catch(InterruptedException e){}
      }
   }
   public void paint(Graphics g){
      Calendar cal = new GregorianCalendar();
	  //g.setBackground(Color.BLUE);
      String hour = String.valueOf(cal.get(Calendar.HOUR));
      String minute = String.valueOf(cal.get(Calendar.MINUTE));
      String second = String.valueOf(cal.get(Calendar.SECOND));
      g.drawString(hour + ":" + minute + ":" + second, 20, 30);
   }
}	

