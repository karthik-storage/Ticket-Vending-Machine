/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication8;


import java.sql.*;
import javax.swing.*;
public class MYSQLConnect {
    Connection conn=null;
    public static Connection ConnectDb(){
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
          Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/tvm","root","karthik");
       return conn;          
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,e);
            return null;
        }
    }
}
